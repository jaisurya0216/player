# Wavelength — a local music player

A single web app for the music you already have. No install, no account,
no server — open `index.html` in a browser and it runs entirely on your
machine. Your library, playlists, likes and play counts are saved on
this device (in the browser's local storage) between visits.

## Getting started

1. Open **`index.html`** in Chrome, Edge, or another Chromium-based
   browser (see "Browser support" below).
2. Click **Add music folder** in the sidebar and choose a folder — for
   example one containing a `music/` folder of songs and a `pictures/`
   folder of cover art. The app scans everything inside, including
   subfolders, and sorts audio from images automatically.
   - Prefer picking files one at a time, or dragging them in? Use
     **Add files**, or just drag audio/image files onto the window
     anywhere — a drop zone will appear.
3. Click **Add from link** to add a song hosted somewhere else — paste
   one or more direct audio URLs (one per line), and optionally a title,
   artist, and cover image URL.

That's it — your library, home screen, and playlists populate
automatically.

## Matching cover art to songs

If a song and an image share the same file name (e.g. `Sunset
Drive.mp3` and `Sunset Drive.jpg`), or sit in the same folder as a
generically-named `cover.jpg` / `folder.jpg` / `album.jpg`, Wavelength
pairs them automatically. Songs with an embedded cover in their ID3
tags use that directly. Anything else gets a clean, generated cover in
the app's own colour palette instead of a broken image icon.

## Reconnecting your music folder

Browsers don't allow web pages to keep access to your files between
visits — that's a deliberate privacy protection, not a bug. Each time
you reopen Wavelength, click **Add music folder** again and re-select
the same folder. Everything about your library — titles, play counts,
likes, playlists, lyrics you've pasted in — is preserved and simply
reconnects to the files. Songs added **by link** need no reconnecting,
since the link itself is saved.

## Features

- Library, Favorites, Search, Albums, Artists, and custom Playlists
- Queue with drag-free reordering (move up/down from a track's menu),
  "play next," and shuffle/repeat (off, all, one)
- A crossfade between manual track changes, so skipping never clicks or pops
- A 6-band equalizer with presets (Bass, Vocal, Treble, Rock, Pop,
  Electronic) plus manual bands
- A radial, audio-reactive visualizer in the expanded Now Playing view
- Per-song lyrics box (typed/pasted, saved locally — Wavelength never
  fetches lyrics from the web)
- Sleep timer, keyboard shortcuts (press **?** in the app for the full
  list), and a library export/import (JSON) for backing up playlists
  and likes

## Browser support

Folder selection uses the File System Access-style
`webkitdirectory` API, which is broadly supported in Chrome, Edge,
Opera, and Brave. Firefox and Safari can still add music via **Add
files** or drag-and-drop — just not whole-folder picking in Safari's
older versions.

## Privacy

Everything runs locally in your browser. Audio files, images, and
metadata are never uploaded anywhere. The only network requests
Wavelength makes are optional: loading its two fonts and a small
tag-reading library from a public CDN, and fetching whatever URL you
explicitly add under "Add from link." Both fail silently and the app
keeps working if you're offline.

## Folder structure

```
wavelength/
├── index.html
├── css/styles.css
├── js/store.js         persistence + state
├── js/library.js        file & link ingestion, art matching
├── js/audio.js           playback engine, crossfade, equalizer
├── js/visualizer.js       the radial now-playing visualizer
├── js/ui.js                everything on screen
├── js/app.js                 startup
├── music/                     put your songs here (or anywhere you like)
└── pictures/                   put your cover art here
```

Enjoy.
